StockBox - Simple JavaFX Inventory (no DB)

How to run:
1. Import the project into NetBeans as a Maven project (File -> Open Project -> navigate to the folder).
2. Make sure you have JDK 17+ and JavaFX SDK (Maven will fetch javafx libs).
3. Right-click project -> Run.

SceneBuilder:
All FXML files are under src/main/resources/fxml and are compatible with Scene Builder.
Open them in Scene Builder to view UI.

Screens included:
- login.fxml
- dashboard.fxml
- products.fxml (add/delete, sample data)
- suppliers.fxml
- customers.fxml
- orders.fxml
- stock_adjust.fxml
- settings.fxml
- about.fxml

No database; uses in-memory DataStore (DataStore.java).